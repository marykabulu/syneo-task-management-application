const { DynamoDB, SES } = require('aws-sdk');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// Initialize AWS services
const dynamoDB = new DynamoDB.DocumentClient();
const ses = new SES({ region: 'us-east-1' }); // Change to your AWS region

// Table names
const USERS_TABLE = 'Users';
const VERIFICATION_CODES_TABLE = 'VerificationCodes';

// JWT secret (in production, use AWS Secrets Manager)
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

module.exports.handler = async (event) => {
  try {
    // Determine which function to run based on the path
    const path = event.path;
    
    // Log request for debugging
    console.log('Request:', {
      path: path,
      method: event.httpMethod,
      body: event.body
    });
    
    // Handle different auth endpoints
    switch(path) {
      case '/auth/register':
        return handleRegister(event);
      case '/auth/verify-code':
        return handleVerifyCode(event);
      case '/auth/login':
        return handleLogin(event);
      case '/auth/forgot-password':
        return handleForgotPassword(event);
      case '/auth/reset-password':
        return handleResetPassword(event);
      case '/auth/me':
        return handleGetCurrentUser(event);
      default:
        return formatResponse(404, { success: false, message: 'Endpoint not found' });
    }
  } catch (error) {
    console.error('Error in auth lambda:', error);
    return formatResponse(500, { success: false, message: 'Internal server error' });
  }
};

/**
 * Handles user registration
 */
async function handleRegister(event) {
  // Parse request body
  const body = JSON.parse(event.body);
  const { firstName, lastName, email, password } = body;
  
  // Validate input
  if (!firstName || !lastName || !email || !password) {
    return formatResponse(400, { success: false, message: 'All fields are required' });
  }
  
  // Check if user already exists
  const existingUser = await dynamoDB.get({
    TableName: USERS_TABLE,
    Key: { email }
  }).promise();
  
  if (existingUser.Item) {
    return formatResponse(409, { success: false, message: 'User with this email already exists' });
  }
  
  // Generate verification code
  const verificationCode = generateVerificationCode();
  
  // Hash password (in production, use a proper password hashing library)
  const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
  
  // Create user in DynamoDB
  const userId = crypto.randomUUID();
  const timestamp = new Date().toISOString();
  
  const newUser = {
    id: userId,
    email,
    firstName,
    lastName,
    password: hashedPassword,
    verified: false,
    createdAt: timestamp,
    updatedAt: timestamp
  };
  
  await dynamoDB.put({
    TableName: USERS_TABLE,
    Item: newUser
  }).promise();
  
  // Store verification code
  const expirationTime = Math.floor(Date.now() / 1000) + 3600; // 1 hour from now
  
  await dynamoDB.put({
    TableName: VERIFICATION_CODES_TABLE,
    Item: {
      email,
      code: verificationCode,
      expiresAt: expirationTime,
      createdAt: timestamp
    }
  }).promise();
  
  // Send verification email
  await sendVerificationEmail(email, verificationCode, firstName);
  
  return formatResponse(201, { 
    success: true, 
    message: 'User registered successfully. Please check your email for verification code.' 
  });
}

/**
 * Handles verification code validation
 */
async function handleVerifyCode(event) {
  // Parse request body
  const body = JSON.parse(event.body);
  const { email, code } = body;
  
  // Validate input
  if (!email || !code) {
    return formatResponse(400, { success: false, message: 'Email and code are required' });
  }
  
  // Check if user exists
  const userResult = await dynamoDB.get({
    TableName: USERS_TABLE,
    Key: { email }
  }).promise();
  
  if (!userResult.Item) {
    return formatResponse(404, { success: false, message: 'User not found' });
  }
  
  // If user is already verified
  if (userResult.Item.verified) {
    return formatResponse(200, { success: true, message: 'Account is already verified' });
  }
  
  // Check verification code
  const codeResult = await dynamoDB.get({
    TableName: VERIFICATION_CODES_TABLE,
    Key: { email }
  }).promise();
  
  if (!codeResult.Item) {
    return formatResponse(404, { success: false, message: 'Verification code not found' });
  }
  
  const storedCode = codeResult.Item.code;
  const expiresAt = codeResult.Item.expiresAt;
  const currentTime = Math.floor(Date.now() / 1000);
  
  // Check if code is expired
  if (currentTime > expiresAt) {
    return formatResponse(400, { success: false, message: 'Verification code has expired' });
  }
  
  // Check if code matches
  if (code !== storedCode) {
    return formatResponse(400, { success: false, message: 'Invalid verification code' });
  }
  
  // Update user as verified
  await dynamoDB.update({
    TableName: USERS_TABLE,
    Key: { email },
    UpdateExpression: 'SET verified = :verified, updatedAt = :updatedAt',
    ExpressionAttributeValues: {
      ':verified': true,
      ':updatedAt': new Date().toISOString()
    }
  }).promise();
  
  // Remove verification code after successful verification
  await dynamoDB.delete({
    TableName: VERIFICATION_CODES_TABLE,
    Key: { email }
  }).promise();
  
  return formatResponse(200, { 
    success: true, 
    message: 'Email verified successfully. You can now login.' 
  });
}

/**
 * Handles user login
 */
async function handleLogin(event) {
  // Parse request body
  const body = JSON.parse(event.body);
  const { email, password } = body;
  
  // Validate input
  if (!email || !password) {
    return formatResponse(400, { success: false, message: 'Email and password are required' });
  }
  
  // Check if user exists
  const userResult = await dynamoDB.get({
    TableName: USERS_TABLE,
    Key: { email }
  }).promise();
  
  if (!userResult.Item) {
    return formatResponse(401, { success: false, message: 'Invalid credentials' });
  }
  
  const user = userResult.Item;
  
  // Check if account is verified
  if (!user.verified) {
    return formatResponse(403, { 
      success: false, 
      message: 'Account not verified. Please check your email for verification code.',
      requiresVerification: true
    });
  }
  
  // Verify password
  const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
  
  if (hashedPassword !== user.password) {
    return formatResponse(401, { success: false, message: 'Invalid credentials' });
  }
  
  // Generate JWT token
  const token = jwt.sign(
    { 
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        verified: user.verified
      } 
    },
    JWT_SECRET,
    { expiresIn: '24h' }
  );
  
  // Return user info and token
  return formatResponse(200, {
    success: true,
    token,
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      verified: user.verified
    }
  });
}

/**
 * Handles forgot password requests
 */
async function handleForgotPassword(event) {
  // Parse request body
  const body = JSON.parse(event.body);
  const { email } = body;
  
  // Validate input
  if (!email) {
    return formatResponse(400, { success: false, message: 'Email is required' });
  }
  
  // Check if user exists
  const userResult = await dynamoDB.get({
    TableName: USERS_TABLE,
    Key: { email }
  }).promise();
  
  // Even if user doesn't exist, don't reveal this information
  // This prevents email enumeration attacks
  if (!userResult.Item) {
    return formatResponse(200, { 
      success: true, 
      message: 'If an account with this email exists, a reset code has been sent.' 
    });
  }
  
  // Generate reset code
  const resetCode = generateVerificationCode();
  const timestamp = new Date().toISOString();
  const expirationTime = Math.floor(Date.now() / 1000) + 3600; // 1 hour from now
  
  // Store reset code
  await dynamoDB.put({
    TableName: VERIFICATION_CODES_TABLE,
    Item: {
      email,
      code: resetCode,
      expiresAt: expirationTime,
      purpose: 'password_reset',
      createdAt: timestamp
    }
  }).promise();
  
  // Send reset code email
  await sendPasswordResetEmail(email, resetCode, userResult.Item.firstName);
  
  return formatResponse(200, { 
    success: true, 
    message: 'Password reset code has been sent to your email.' 
  });
}

/**
 * Handles password reset
 */
async function handleResetPassword(event) {
  // Parse request body
  const body = JSON.parse(event.body);
  const { email, code, password } = body;
  
  // Validate input
  if (!email || !code || !password) {
    return formatResponse(400, { success: false, message: 'Email, code, and new password are required' });
  }
  
  // Check if user exists
  const userResult = await dynamoDB.get({
    TableName: USERS_TABLE,
    Key: { email }
  }).promise();
  
  if (!userResult.Item) {
    return formatResponse(404, { success: false, message: 'User not found' });
  }
  
  // Check verification code
  const codeResult = await dynamoDB.get({
    TableName: VERIFICATION_CODES_TABLE,
    Key: { email }
  }).promise();
  
  if (!codeResult.Item || codeResult.Item.purpose !== 'password_reset') {
    return formatResponse(400, { success: false, message: 'Invalid or expired code' });
  }
  
  const storedCode = codeResult.Item.code;
  const expiresAt = codeResult.Item.expiresAt;
  const currentTime = Math.floor(Date.now() / 1000);
  
  // Check if code is expired
  if (currentTime > expiresAt) {
    return formatResponse(400, { success: false, message: 'Reset code has expired' });
  }
  
  // Check if code matches
  if (code !== storedCode) {
    return formatResponse(400, { success: false, message: 'Invalid reset code' });
  }
  
  // Hash new password
  const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
  
  // Update user's password
  await dynamoDB.update({
    TableName: USERS_TABLE,
    Key: { email },
    UpdateExpression: 'SET password = :password, updatedAt = :updatedAt',
    ExpressionAttributeValues: {
      ':password': hashedPassword,
      ':updatedAt': new Date().toISOString()
    }
  }).promise();
  
  // Remove verification code after successful reset
  await dynamoDB.delete({
    TableName: VERIFICATION_CODES_TABLE,
    Key: { email }
  }).promise();
  
  return formatResponse(200, { 
    success: true, 
    message: 'Password has been reset successfully. You can now login with your new password.' 
  });
}

/**
 * Handles getting the current user information
 */
async function handleGetCurrentUser(event) {
  // Get authorization header
  const authHeader = event.headers.Authorization || event.headers.authorization;
  
  if (!authHeader) {
    return formatResponse(401, { success: false, message: 'No authorization token provided' });
  }
  
  // Extract token from header (Bearer token)
  const token = authHeader.replace('Bearer ', '');
  
  try {
    // Verify and decode JWT
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // Return user info
    return formatResponse(200, {
      success: true,
      user: decoded.user
    });
  } catch (error) {
    return formatResponse(401, { success: false, message: 'Invalid or expired token' });
  }
}

/**
 * Formats the response in a consistent way
 */
function formatResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'OPTIONS,GET,POST,PUT,DELETE',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization'
    },
    body: JSON.stringify(body)
  };
}

/**
 * Generates a 6-digit verification code
 */
function generateVerificationCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Sends verification email using SES
 */
async function sendVerificationEmail(email, code, firstName) {
  const params = {
    Source: 'your-verified-email@example.com', // Must be verified in SES
    Destination: {
      ToAddresses: [email]
    },
    Message: {
      Subject: {
        Data: 'Verify Your Account'
      },
      Body: {
        Html: {
          Data: `
            <html>
              <head>
                <style>
                  body { font-family: Arial, sans-serif; line-height: 1.6; }
                  .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                  .code { font-size: 24px; background-color: #f0f0f0; padding: 10px; text-align: center; }
                </style>
              </head>
              <body>
                <div class="container">
                  <h1>Hi ${firstName},</h1>
                  <p>Thank you for registering. Please use the following code to verify your account:</p>
                  <div class="code">${code}</div>
                  <p>This code will expire in 1 hour.</p>
                  <p>If you didn't request this, please ignore this email.</p>
                </div>
              </body>
            </html>
          `
        }
      }
    }
  };
  
  return ses.sendEmail(params).promise();
}

/**
 * Sends password reset email using SES
 */
async function sendPasswordResetEmail(email, code, firstName) {
  const params = {
    Source: 'your-verified-email@example.com', // Must be verified in SES
    Destination: {
      ToAddresses: [email]
    },
    Message: {
      Subject: {
        Data: 'Reset Your Password'
      },
      Body: {
        Html: {
          Data: `
            <html>
              <head>
                <style>
                  body { font-family: Arial, sans-serif; line-height: 1.6; }
                  .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                  .code { font-size: 24px; background-color: #f0f0f0; padding: 10px; text-align: center; }
                </style>
              </head>
              <body>
                <div class="container">
                  <h1>Hi ${firstName},</h1>
                  <p>We received a request to reset your password. Please use the following code:</p>
                  <div class="code">${code}</div>
                  <p>This code will expire in 1 hour.</p>
                  <p>If you didn't request this, please ignore this email.</p>
                </div>
              </body>
            </html>
          `
        }
      }
    }
  };
  
  return ses.sendEmail(params).promise();
}